NyxOS Wallpaper Pack
====================

144 wallpapers, rendered by the operating system that draws them.

NyxOS is a 64-bit operating system written from scratch in C and x86_64 Assembly.
Its desktop background is not an image file — the compositor paints it from code on
every frame, with integer arithmetic only, because the kernel is built with no
floating point anywhere. Twelve render styles over eleven base colours.

These PNGs were produced by compiling that exact painter — draw_background() out of
kernel/gui/core/compositor.c — against a plain memory framebuffer instead of the
video hardware. Same maths, same deterministic star seed. They are the pixels the
OS puts on screen, not a recreation of them.


What is in here
---------------

1920x1080/   132 wallpapers — every style in every base colour.
             This is the resolution the desktop is designed for, so these match
             the real NyxOS desktop pixel for pixel.

3840x2160/   12 wallpapers — every style in the brand purple, rendered natively
             at 4K (not upscaled). The sky, aurora, nebula, rain and mountains are
             all framebuffer-relative and gain real detail; the moon and the stars
             keep their absolute pixel size, so the scene reads wider and calmer
             than it does at 1080p. Some people prefer it.

The six animated styles (Estrellas, Meteoros, Aurora, Nebula, Luces, Ondas, Lluvia)
are pure functions of the system clock, so a still is simply one chosen tick. The
meteor, for instance, exists for only 900 ms out of every 3.6 s.


The styles
----------

Limpio       a clean vertical gradient
Nightfall    the classic scene: gradient, moon, star field  (the default)
Plano        a single flat colour
Estrellas    Nightfall, stars twinkling
Meteoros     Nightfall with a periodic shooting star
Aurora       Nightfall with drifting aurora curtains
Nebula       Nightfall with soft drifting nebula clouds
Luces        Nightfall with slow rising fireflies
Ondas        Nightfall with moonlight ripples spreading from the moon
Astral       Nightfall with a star map — constellations joined by faint threads
Lluvia       Nightfall with a soft rain of falling lilac star-light
Cordillera   Nightfall with layered silhouettes of night mountains

Base colours: Morado (the brand purple), Azul, Turquesa, Verde, Lima, Oro,
Naranja, Rojo, Rosa, Pizarra, Carbon.


Licence
-------

GPL-2.0-or-later, same as NyxOS itself. Use them anywhere, including commercially;
if you redistribute the renderer, keep it under the GPL.


The OS
------

  Site      https://nyxos.cc
  Source    https://github.com/kazah-png/nyx-os
  Discord   https://dsc.gg/nyxos

NyxOS is free and stays free. If the pack was worth something to you:

  https://nyxos.cc/support.html

Worth more than money: write the ISO to a USB stick, boot a machine you do not
care about, and open an issue with the last line that appeared before it stopped.
Real-metal reports are the rarest thing this project gets.

Built for the metal.
